<?php

namespace App\Controller\Admin;

use App\Entity\Products;
use App\Form\ProductsFormType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\String\Slugger\SluggerInterface;

#[Route('/admin/produits', name: 'admin_produits_')]
class ProductsController extends AbstractController
{
    #[Route('/', name: 'index')]
    public function index(): Response
    {
        return $this->render('admin/products/index.html.twig', compact('produits'));
    }

    #[Route('/ajout', name: 'add')]
    public function add(Request $request, EntityManagerInterface $em, SluggerInterface $slugger): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');

        // Création d'un nouveau produit
        $product = new Products();

        // Création d'un nouveau formulaire
        $productForm = $this->createForm(ProductsFormType::class, $product);

        //Traitement de la requête de formulaire
        $productForm->handleRequest($request);

        // Verification de la validité du formulaire
        if($productForm->isSubmitted() && $productForm->isValid()){
            // Génération du slug
            $slug =  $slugger->slug($product->getName());
            $product->setSlug($slug);
        

        // Le prix est arrondi
        $prix = $product->getPrice() * 100;
        $product->setPrice($prix);

        $em->persist($product);
        $em->flush();

        $this->addFlash('success', 'Produit ajouté avec succès');

        // Redirection
        return $this->redirectToRoute('admin_products_index');
        
        }
        
        //return $this->render('admin/products/add.html.twig',[
        //    'productForm' => $productForm->createView()
        //]);

        return $this->renderForm('admin/products/add.html.twig', compact('productForm'));
        // ['productForm' => $productForm]
    }
    #[Route('/edition/{id}', name: 'edit')]
    public function edit(Products $product, Request $request, EntityManagerInterface $em, SluggerInterface $slugger): Response
    {
        // On vérifie si l'utilisateur peut éditer avec le voter
        $this->denyAccessUnlessGranted('PRODUCT_EDIT', $product);

        // On divise le prix par 100
        // $prix = $product->getPrice() / 100;
        // $product->setPrice($prix);

        // Création d'un nouveau formulaire
        $productForm = $this->createForm(ProductsFormType::class, $product);

        //Traitement de la requête de formulaire
        $productForm->handleRequest($request);

        // Verification de la validité du formulaire
        if($productForm->isSubmitted() && $productForm->isValid()){
            // Génération du slug
            $slug =  $slugger->slug($product->getName());
            $product->setSlug($slug);
        

        // Le prix est arrondi
        $prix = $product->getPrice() * 100;
        $product->setPrice($prix);

        $em->persist($product);
        $em->flush();

        $this->addFlash('success', 'Produit modifié avec succès');

        // Redirection
        return $this->redirectToRoute('admin_products_index');

        }

        
        return $this->render('admin/products/edit.html.twig',[
            'productForm' => $productForm->createView(),
            'product' => $product
        ]);

        //return $this->renderForm('admin/products/edit.html.twig', compact('productForm'));
        // ['productForm' => $productForm]
    }

    #[Route('/suppression/{id}', name: 'delete')]
    public function delete(Products $product): Response
    {
        // On vérifie si l'utilisateur peut supprimer avec le voter
        $this->denyAccessUnlessGranted('PRODUCT_DELETE', $product);
        return $this->render('admin/products/index.html.twig');
    }
}